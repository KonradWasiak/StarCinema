﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using StarCinema.DataLayer.Abstract;
using StarCinema.Models;
using StarCinema.Models.CRUDModels.CinemaModels;

namespace StarCinema.Controllers
{
    public class CinemaController : Controller
    {
        private readonly ICinemaRepository _cinemaRepo;
        private readonly ICityRepository _cityRepo;

        public CinemaController(ICinemaRepository cinemaRepo, ICityRepository cityRepo)
        {
            this._cinemaRepo = cinemaRepo;
            this._cityRepo = cityRepo;
        }

        public async Task<IActionResult> Cinemas(int id)
        {
            var allCinemas = await this._cinemaRepo.PaginatedCinemas(id, PagingInfo.ItemsPerPage);

            List<CinemaViewModel> cinemasViewModelList = new List<CinemaViewModel>();
            allCinemas.ToList().ForEach(x => cinemasViewModelList.Add(new CinemaViewModel(x)));

            int cinemasCount = await this._cinemaRepo.CinemasCount();
            int totalPages = cinemasCount % PagingInfo.ItemsPerPage > 0 ? cinemasCount / PagingInfo.ItemsPerPage + 1 : cinemasCount / PagingInfo.ItemsPerPage;

            var categoriesViewModel = new PaginatedCinemaViewModel(cinemasViewModelList, new PagingInfo
            {
                CurrentPage = id,
                TotalPages = totalPages
            }); ;
            return View(categoriesViewModel);
        }
        public IActionResult CinemasFromCity()
        {
            return View();
        }

        public async Task<IActionResult> CreateCinema()
        {
            var cities = await _cityRepo.AllCities();
            return View(new AddCinemaViewModel(cities));
        }
        [HttpPost]
        public IActionResult CreateCinema(AddCinemaViewModel cinema)
        {
            cinema.CreateCinemaHalls();
            return View("AddHallsToCinema", cinema);
        }

        [HttpPost]
        public IActionResult AddHallsToCinema(AddCinemaViewModel cinema)
        {
            return View("CreateCinema");

        }
        //[HttpPost]
        //public IActionResult RemoveCinema(CinemaViewModel cinema)
        //{
        //    ////var cinemaToRemove = cinema.ToEntity();
        //    //this._cinemaRepo.RemoveCinema(cinemaToRemove);
        //    //return View(cinemaToRemove);
        //}
        public IActionResult EditCinema()
        {
            return View();
        }



    }
}