﻿using StarCinema.Models.BookingModels;
using StarCinema.Models.CRUDModels.CinemaHallModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarCinema.Models.CRUDModels.ShowModel
{
    public class ShowViewModel
    {
        public int Id { get; set; }
        public int MovieId { get; set; }
        public MovieViewModel Movie { get; set; }
        public CinemaHallViewModel Hall { get; set; }
        public DateTime Date { get; set; }
        public List<BookingViewModel> Bookings { get; set; }
    }
}
