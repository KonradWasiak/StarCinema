﻿using StarCinema.DomainModels;
using StarCinema.Models.CRUDModels.AddressModels;
using StarCinema.Models.CRUDModels.CinemaHallModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarCinema.Models.CRUDModels.CinemaModels
{
    public class CinemaViewModel
    {
        public int Id { get; set; }
        public City City { get; set; }
        public List<CinemaHallViewModel> CinemaHalls { get; set; }        
        public AddressViewModel Address { get; set; }

        public CinemaViewModel(Cinema cinema)
        {
            //this.CinemaHalls = cinema.CinemaHalls.ToList();
            this.City = cinema.City;
            this.Id = cinema.Id;
        }
        public CinemaViewModel()
        {
            this.CinemaHalls = new List<CinemaHallViewModel>();
            Address = new AddressViewModel();
        }

        //public virtual Cinema ToEntity()
        //{
        //    List<CinemaHall> halls = new List<CinemaHall>();
        //    return new Cinema()
        //    {
        //        Id = this.Id,
        //        CinemaHalls
        //        City = this.City
        //    };
        //}
    }
}
