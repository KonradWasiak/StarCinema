﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using StarCinema.DomainModels;
using StarCinema.Models.CRUDModels.CinemaHallModels;

namespace StarCinema.Models.CRUDModels.CinemaModels
{
    public class AddCinemaViewModel : CinemaViewModel
    {
        public List<SelectListItem> AllCities { get; set; }
        public int HallsCount { get; set; }

        public AddCinemaViewModel(List<City> citites)
        {
            AllCities = new List<SelectListItem>();
            citites.ForEach(c => AllCities.Add(GetCitySelectListItem(c)));
        }
        public AddCinemaViewModel(Cinema cinema) : base(cinema)
        {
            this.AllCities = new List<SelectListItem>();
        }

        public AddCinemaViewModel()
        {
        }

        public void CreateCinemaHalls()
        {
            for (int i = 0; i < HallsCount; i++)
            {
                base.CinemaHalls.Add(new CinemaHallViewModel() 
                { 
                });
            }
        }
        private SelectListItem GetCitySelectListItem(City city)
        {
            return new SelectListItem()
            {
                Text = city.CityName,
                Value = city.Id.ToString()
            };
        }
        private CinemaHallViewModel CreateCinemaHallViewModel()
        {
            return new CinemaHallViewModel()
            {
                Cinema = this
            };
        }

        //public override Cinema ToEntity()
        //{
        //    return new Cinema()
        //    {
        //        Id = base.Id,
        //        CinemaHalls = 
        //    }
        //}

        private CinemaHall CreateCinemaHall(CinemaHallViewModel hall)
        {
            //TWORZYC MIEJSCA DO SAL  RECZNIE

            return new CinemaHall()
            {
                Id = hall.Id,
                Name = hall.Name,
                Seats = new List<Seat>(hall.SeatsCount)
            };
        }

    }
}
