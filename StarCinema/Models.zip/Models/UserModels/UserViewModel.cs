﻿using StarCinema.Models.BookingModels;
using StarCinema.Models.CRUDModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarCinema.Models.UserModels
{
    public class UserViewModel
    {
        public string UserName { get; set; }
        public string Email { get; set; }
        public List<CommentViewModel> Comments { get; set; }
        public List<RateViewModel> Rates { get; set; }
        public List<BookingViewModel> Bookings { get; set; }

    }
}
