﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarCinema.DomainModels
{
    public class City
    {
        public int Id { get; set; }
        public string CityName { get; set; }
        public ICollection<Cinema> Cinemas { get; set; }

    }
}
