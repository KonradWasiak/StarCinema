﻿using StarCinema.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StarCinema.DataLayer.Abstract
{
    public interface ICinemaRepository
    {
        void AddCinema(Cinema cinema);
        Task<Cinema> RemoveCinema(Cinema cinema);
        Task<IEnumerable<Cinema>> AllCinemas();
        Task<IEnumerable<Cinema>> FindMoviesFromCity(string city);
        Task<int> CinemasCount();
        Task<IEnumerable<Cinema>> PaginatedCinemas(int page, int itemsPerPage);
    }
}
